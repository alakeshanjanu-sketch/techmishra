Mishra Tech Website Setup
=========================

Instructions:
1. Replace placeholder images in the 'images/' folder with real images.
2. Update 'form' action in index.html with your Formspree form ID.
3. Upload all files to GitHub repository or hosting provider.
4. Enable GitHub Pages or your hosting to go live.

Sections:
- Hero: Header banner and tagline
- About: Company description
- Services: Three service cards
- Video: Link to YouTube channel
- Contact: Email, WhatsApp, Facebook, and contact form
- Footer: Copyright info
